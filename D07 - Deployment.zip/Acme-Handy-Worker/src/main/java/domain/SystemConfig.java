
package domain;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.validation.constraints.DecimalMax;
import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;

import org.hibernate.validator.constraints.Range;

@Entity
@Access(AccessType.PROPERTY)
public class SystemConfig extends DomainEntity {

	//ATRIBUTOS DEL SISTEMA.
	public List<String>			badWords;
	public List<String>			goodWords;
	public Double				finderTimer;
	public Integer				finderMaxResults;
	public String				name;
	public String				banner;
	public Collection<String>	welcomeMessage;
	public List<String>			spamWords;
	public Double				vat;
	public String				phonePrefix;
	public List<String>			creditCardPrefix;


	public enum badWords {
		NOT, BAD, HORRIBLE, AVERAGE, DISASTER
	};

	public enum goodWords {
		GOOD, FANTASTIC, EXCELLENT, GREAT, AMAZING, TERRIFIC, BEAUTIFUL
	}


	@Column
	@ElementCollection(targetClass = String.class)
	public List<String> getBadWords() {
		return this.badWords;
	}

	public void setBadWords(final List<String> badWords) {
		this.badWords = badWords;
	}
	@Column
	@ElementCollection(targetClass = String.class)
	public List<String> getGoodWords() {
		return this.goodWords;
	}

	public void setGoodWords(final List<String> goodWords) {
		this.goodWords = goodWords;
	}
@Min(value =0L)
	public Double getFinderTimer() {
		return this.finderTimer;
	}

	public void setFinderTimer(final Double finderTimer) {
		this.finderTimer = finderTimer;
	}
	@Min(value =0L)
	@Max(value = 100)
	public Integer getFinderMaxResults() {
		return this.finderMaxResults;
	}

	public void setFinderMaxResults(final Integer finderMaxResults) {
		this.finderMaxResults = finderMaxResults;
	}

	public String getName() {
		return this.name;
	}

	public void setName(final String name) {
		this.name = name;
	}

	public String getBanner() {
		return this.banner;
	}

	public void setBanner(final String banner) {
		this.banner = banner;
	}
	@ElementCollection(targetClass = String.class)
	public Collection<String> getWelcomeMessage() {
		return this.welcomeMessage;
	}
	public void setWelcomeMessage(final Collection<String> welcomeMessage) {
		this.welcomeMessage = welcomeMessage;
	}
	@Column
	@ElementCollection(targetClass = String.class)
	public List<String> getSpamWords() {
		return this.spamWords;
	}

	public void setSpamWords(final List<String> spamWords) {
		this.spamWords = spamWords;
	}
@DecimalMax("1.00")
@DecimalMin("0.00")
	public Double getVat() {
		return this.vat;
	}

	public void setVat(final Double vat) {
		this.vat = vat;
	}

	public String getPhonePrefix() {
		return this.phonePrefix;
	}

	public void setPhonePrefix(final String phonePrefix) {
		this.phonePrefix = phonePrefix;
	}
	@Column
	@ElementCollection(targetClass = String.class)
	public List<String> getCreditCardPrefix() {
		return this.creditCardPrefix;
	}

	public void setCreditCardPrefix(final List<String> creditCardPrefix) {
		this.creditCardPrefix = creditCardPrefix;
	}


	public static final List<String> staticgetSpamWords() {
		final List<String> res = new ArrayList<String>();

		res.add("sex");
		res.add("viagra");
		res.add("cialis");
		res.add("one million");
		res.add("you've been selected");
		res.add("Nigeria");
		res.add("sexo");
		res.add("un millon");
		res.add("ha sido seleccionado");

		return res;
	}

	//A�adir el resto de cosas

}
