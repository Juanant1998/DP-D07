package controllers;

import java.util.Collection;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.Assert;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import domain.Application;
import domain.Complaint;
import domain.Report;
import domain.Warranty;

import services.ComplaintService;
import services.RefereeService;
import services.ReportService;

@Controller
@RequestMapping("/report/referee")
public class ReportRefereeController extends AbstractController {
@Autowired
private ReportService reportService;
@Autowired
private RefereeService refereeService;




@RequestMapping(value ="/list" ,method =RequestMethod.GET)
public ModelAndView list (){
	
	ModelAndView result;
	
	final Collection<Report> col= this.refereeService.getMyReports();
	
	result= new ModelAndView("report/list");
	result.addObject("reports", col);
	result.addObject("requestURI","/report/referee/list.do");
	return  result;
}


@RequestMapping(value="/create", method = RequestMethod.GET)
public ModelAndView create(@RequestParam int complaintId){
	ModelAndView result;
	Report report ;
	


	 
	// cambio  de warrantyService.create() a 
	report=this.reportService.create();
    report.setId(complaintId);
	result = this.createEditModelAndView(report);
	result.addObject("complaintId", complaintId);
	
	
	return result;
}


@RequestMapping(value ="/edit" ,method =RequestMethod.GET)
public ModelAndView edit (@RequestParam int reportId){
	
	ModelAndView result;
	Report report;
	report = reportService.findOne(reportId);
	
	Assert.notNull(report);
	result = createEditModelAndView(report);
	return result;
	
}
@RequestMapping(value="/edit",method=RequestMethod.POST,params="save")
public ModelAndView save(@Valid Report report,BindingResult binding){
ModelAndView result;

System.out.println(report.getDescription());
System.out.println(report.getAttachments());
System.out.println(report.isDraftMode());
System.out.println(report.getMoment());
System.out.println(report.getNotes());
System.out.println(report.getReferee());


  if(binding.hasErrors()){
	result=createEditModelAndView(report);
	System.out.println(" si tiene error aqui");
   }else{
	try{
		System.out.println(" entra aqui en try");
		
		final int complaintId = report.getId();
		report.setId(0);
		final Report savedreport = this.reportService.save(report);

		
		this.reportService.relateComplaintToReport(complaintId, savedreport);
		this.reportService.save(report);
		
		result = new ModelAndView("redirect:list.do");
	}catch(Throwable oops){
		result = createEditModelAndView(report,"report.commit.error");
	}
	
}
	
return result;
	
}


protected ModelAndView createCreateModelAndView(final Report c) {
	ModelAndView result;
	result = this.createCreateModelAndView(c, null);

	return result;
}

protected ModelAndView createCreateModelAndView(final Report c, final String messageCode) {
	ModelAndView result;
	result = new ModelAndView("applications/create");
	result.addObject("application", c);
//	final String banner = this.scs.getSystemConfig().getBanner();
//	result.addObject("bannerImage", banner);
	result.addObject("message", messageCode);

	return result;

}














@RequestMapping(value = "/display", method = RequestMethod.GET)
public ModelAndView display(@RequestParam final int reportId) {
	ModelAndView result;
	Report report;

	report = this.reportService.findOne(reportId);
	Assert.notNull(report);

	result = this.createDisplayModelAndView(report);

	return result;
}


/*	@RequestMapping(value="/edit",method=RequestMethod.POST,params="delete")
	public ModelAndView delete(@Valid Warranty warranty,BindingResult binding){
	ModelAndView result;
	
	
		try{
			this.warrantyService.delete(warranty);
			result = new ModelAndView("redirect:list.do");
		}catch(Throwable oops){
			result = createEditModelAndView(warranty,"warranty.commit.error");
		}
 * 
 */

@RequestMapping(value="/edit",method=RequestMethod.POST,params="delete")
public ModelAndView delete(@Valid Report report,BindingResult binding){
ModelAndView result;
System.out.println();


try{
	
	this.reportService.delete(report);
	result = new ModelAndView("redirect:list.do");
}catch(Throwable oops){
	result = createEditModelAndView(report,"warranty.commit.error");
}
	

	
return result;
	
}












protected ModelAndView createEditModelAndView(Report report){
	ModelAndView result;
	
	result= createEditModelAndView(report,null);
	return result;
}
protected ModelAndView createEditModelAndView(Report report ,String messageCode){
	

	 
	ModelAndView result;
	result =new ModelAndView("report/edit");
	result.addObject("report",report);
	result.addObject("message",messageCode);
	return result;
	
	
	
	
}

protected ModelAndView createDisplayModelAndView(final Report c) {
	ModelAndView result;
	result = this.createDisplayModelAndView(c, null);

	return result;
}

protected ModelAndView createDisplayModelAndView(final Report c, final String messageCode) {
	ModelAndView result;
	result = new ModelAndView("report/display");
	result.addObject("report", c);

	result.addObject("message", messageCode);

	return result;

}
}