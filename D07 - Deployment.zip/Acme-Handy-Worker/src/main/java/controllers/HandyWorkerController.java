
package controllers;

import java.util.ArrayList;
import java.util.Collection;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.Assert;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import security.Authority;
import security.LoginService;
import security.UserAccount;
import security.UserAccountRepository;
import services.HandyWorkerService;
import services.SystemConfigService;
import domain.HandyWorker;

@Controller
@RequestMapping("/handyworker")
public class HandyWorkerController extends AbstractController {

	@Autowired
	private UserAccountRepository	userAccountRepository;

	@Autowired
	private HandyWorkerService		hwService;
	@Autowired
	private SystemConfigService		scs;


	// Create ---------------------------------------------------------------		

	@RequestMapping(value = "/create")
	public ModelAndView create() {
		ModelAndView result;
		HandyWorker handyWorker;

		handyWorker = this.hwService.create();
		result = this.createEditModelAndView(handyWorker);

		return result;
	}

	// Edit ---------------------------------------------------------------		

	@RequestMapping(value = "/edit", method = RequestMethod.GET)
	public ModelAndView edit() {
		ModelAndView result;
		HandyWorker handyWorker;

		final UserAccount uA = LoginService.getPrincipal();
		handyWorker = this.userAccountRepository.getHandyByUserAccount(uA.getUsername());
		Assert.notNull(handyWorker);

		result = this.createEditModelAndView(handyWorker);

		return result;
	}

	// Edit Make ---------------------------------------------------------------		

	@RequestMapping(value = "/edit_make", method = RequestMethod.GET)
	public ModelAndView editMake() {
		ModelAndView result;
		HandyWorker handyWorker;

		final UserAccount uA = LoginService.getPrincipal();
		handyWorker = this.userAccountRepository.getHandyByUserAccount(uA.getUsername());
		Assert.notNull(handyWorker);

		result = this.createEditMakeModelAndView(handyWorker);

		return result;
	}

	// Save ---------------------------------------------------------------	

	@RequestMapping(value = "/edit", method = RequestMethod.POST, params = "save")
	public ModelAndView save(@Valid final HandyWorker handyworker, final BindingResult binding) {
		ModelAndView result;
		System.out.println(handyworker.getAddress());
		System.out.println(handyworker.getId());

		final Collection<Authority> authorities = new ArrayList<Authority>();

		final Authority cust = new Authority();
		//System.out.println(cust);
		cust.setAuthority(Authority.HANDYWORKER);

		authorities.add(cust);
		//System.out.println(authorities);
		handyworker.getUserAccount().setAuthorities(authorities);
		System.out.println(handyworker.getUserAccount().getAuthorities());

		System.out.println(handyworker.getMake());
		System.out.println(handyworker.getEmail());
		System.out.println(handyworker.getMessageBoxes());

		System.out.println(handyworker.getProfiles());
		System.out.println(handyworker.getAddress());
		System.out.println(handyworker.getCurriculum());

		System.out.println("antes del if");
		if (binding.hasErrors()) {
			System.out.println("binding");
			result = this.createEditModelAndView(handyworker);
			System.out.println("despues del editmodelandview");
		} else
			try {
				System.out.println("try");

				this.hwService.save(handyworker);
				result = new ModelAndView("redirect:/welcome/index.do");

			} catch (final Throwable oops) {
				result = this.createEditModelAndView(handyworker, "handyworker.commit.error");
			}

		return result;
	}

	protected ModelAndView createEditModelAndView(final HandyWorker handyworker) {
		ModelAndView result;

		result = this.createEditModelAndView(handyworker, null);

		return result;
	}

	protected ModelAndView createEditModelAndView(final HandyWorker handyworker, final String messageCode) {
		ModelAndView result;

		//System.out.println(cust);

		//System.out.println(authorities);

		//System.out.println(customer.getUserAccount().getAuthorities());
		result = new ModelAndView("handyworker/edit");
		result.addObject("handyworker", handyworker);

		result.addObject("message", messageCode);
		final String banner = this.scs.getSystemConfig().getBanner();
		result.addObject("bannerImage", banner);
		return result;
	}

	//Model and View of Make

	protected ModelAndView createEditMakeModelAndView(final HandyWorker handyworker) {
		ModelAndView result;

		result = this.createEditMakeModelAndView(handyworker, null);

		return result;

	}

	protected ModelAndView createEditMakeModelAndView(final HandyWorker handyworker, final String messageCode) {
		ModelAndView result;

		result = new ModelAndView("handyworker/edit_make");
		result.addObject("handyworker", handyworker);

		result.addObject("message", messageCode);
		final String banner = this.scs.getSystemConfig().getBanner();
		result.addObject("bannerImage", banner);
		return result;
	}

}
