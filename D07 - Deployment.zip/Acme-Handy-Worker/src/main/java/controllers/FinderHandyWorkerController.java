package controllers;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.Assert;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import repositories.CategoryRepository;
import repositories.WarrantyRepository;
import security.LoginService;
import security.UserAccount;
import security.UserAccountRepository;
import services.FinderService;
import services.FixUpTaskService;
import services.SystemConfigService;
import domain.Category;
import domain.Finder;
import domain.FixUpTask;
import domain.HandyWorker;
import domain.SystemConfig;
import domain.Warranty;

@Controller
@RequestMapping("/finder/handyworker")
public class FinderHandyWorkerController extends AbstractController {

	@Autowired
	private FinderService finderService;
	@Autowired
	private WarrantyRepository warrantyRepository;
	@Autowired
	private SystemConfigService scs;
	@Autowired
	private CategoryRepository categoryRepository;
	@Autowired
	private UserAccountRepository ur;
	@Autowired
	private SystemConfigService sc;
	@Autowired
	private FixUpTaskService futs;

	public FinderHandyWorkerController() {
		super();
	}

	@RequestMapping(value = "/edit", method = RequestMethod.GET)
	public ModelAndView edit() {
		ModelAndView result;
		Finder finder;
		// cambio de warrantyService.create() a
		final UserAccount usr = LoginService.getPrincipal();
		final HandyWorker hw = this.ur.getHandyByUserAccount(usr.getUsername());
		finder = this.finderService.findOne(hw.getFinder().getId());
		result = this.createEditModelAndView(finder);
		return result;

	}

	@RequestMapping(value = "/edit", method = RequestMethod.POST, params = "search")
	public ModelAndView save(@Valid final Finder finder,
			final BindingResult binding) {
		ModelAndView result = null;

		// ES NECESARIO ENCONTRAR TODAS LAS QUE NO TENGAN UNA ACEPTADA????

		final Date n = new Date();
		System.out.println(n);
		System.out.println(finder.getLastModified());
		final Long res = n.getTime() - finder.getLastModified().getTime();
		final double tiempo = (double) res / (1000 * 60);
		System.out.println(tiempo);

		final SystemConfig df = this.sc.getSystemConfig();
		final UserAccount usr = LoginService.getPrincipal();
		final HandyWorker hw = this.ur.getHandyByUserAccount(usr.getUsername());
		final Finder finderDelHandy = hw.getFinder();

		System.out.println(finder.getQuery());
		System.out.println(finderDelHandy.getQuery());
		System.out.println(finder.getFixUpTasks());
		System.out.println("----" + finderDelHandy.getFixUpTasks());

		if (tiempo < df.getFinderTimer() && finder.equals(finderDelHandy)) {
			System.out.println("con cache");
			finder.setLastModified(n);

			finder.setFixUpTasks(finderDelHandy.getFixUpTasks());
			

			final List<FixUpTask> col = (List<FixUpTask>) finderDelHandy
					.getFixUpTasks();
			int i = this.scs.getSystemConfig().getFinderMaxResults();

			if (col.size() > i) {
				for (int x = 0; x <= i; x++) {
					col.remove(col.get(x));
				}
			}

			System.out.println(col);
			result = new ModelAndView("fixuptask/list");

			result.addObject("fixuptasks", col);

			result.addObject("requestURI", "/fixuptask/handyworker/list.do");
			final Map<String, Double> listaConIva = this.futs.ivaCalculate(col);

			result.addObject("iva", listaConIva);

			if (binding.hasErrors())
				result = this.createEditModelAndView(finder);
			else {

				try {

					this.finderService.save(finder);
				} catch (final Throwable oops) {
					result = this.createEditModelAndView(finder,
							"finder.commit.error");
				}
				return result;
			}

		}

		System.out.println("sin cache");

		final Finder sq = this.finderService.allFilters(finder);
		finder.setFixUpTasks(sq.getFixUpTasks());
		System.out.println("---" + finder.getFixUpTasks());
		finder.setLastModified(n);
		final List<FixUpTask> colu = (List<FixUpTask>) finder.getFixUpTasks();

		int i = this.scs.getSystemConfig().getFinderMaxResults();

		if (colu.size() > i) {
			for (int x = 0; x <= i; x++) {
				colu.remove(colu.get(x));
			}
		}

		result = new ModelAndView("fixuptask/list");
		final Map<String, Double> listaConIva = this.futs.ivaCalculate(colu);

		result.addObject("iva", listaConIva);
		result.addObject("fixuptasks", colu);

		result.addObject("requestURI", "/fixuptask/handyworker/list.do");

		if (binding.hasErrors())
			result = this.createEditModelAndView(finder);
		else
			try {

				this.finderService.save(finder);
			} catch (final Throwable oops) {
				result = this.createEditModelAndView(finder,
						"finder.commit.error");
			}
		return result;
	}

	protected ModelAndView createEditModelAndView(final Finder f) {
		ModelAndView result;
		result = this.createEditModelAndView(f, null);

		return result;
	}

	protected ModelAndView createEditModelAndView(final Finder f,
			final String messageCode) {
		ModelAndView result;
		Collection<Finder> finderlist;
		final List<Warranty> warN = new ArrayList<>();
		final List<Category> catN = new ArrayList<>();

		for (final Warranty w : this.warrantyRepository.findAll())
			warN.add(w);

		for (final Category ca : this.categoryRepository.findAll())
			catN.add(ca);

		finderlist = this.finderService.findAll();
		if (finderlist.contains(f))
			finderlist.remove(f);

		result = new ModelAndView("finder/edit");
		result.addObject("finder", f);
		result.addObject("list", finderlist);
		result.addObject("WarN", warN);
		result.addObject("CatN", catN);
		final String banner = this.scs.getSystemConfig().getBanner();
		result.addObject("bannerImage", banner);
		result.addObject("message", messageCode);

		return result;
	}

}
