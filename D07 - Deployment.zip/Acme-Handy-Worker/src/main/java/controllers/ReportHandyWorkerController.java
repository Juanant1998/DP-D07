package controllers;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import services.HandyWorkerService;


import domain.Report;

@Controller
@RequestMapping("/report/handyworker")
public class ReportHandyWorkerController {
	@Autowired
	private HandyWorkerService handyWorkerService;

	
	
	@RequestMapping(value ="/list" ,method =RequestMethod.GET)
	public ModelAndView list (){
		
		ModelAndView result;
		
		final Collection<Report> col= this.handyWorkerService.getMyReports();
		
		result= new ModelAndView("report/list");
		result.addObject("reports", col);
		result.addObject("requestURI","/report/handyworker/list.do");
		return  result;
	}
	
}
