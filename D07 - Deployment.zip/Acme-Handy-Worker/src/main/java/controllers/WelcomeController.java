/*
 * WelcomeController.java
 * 
 * Copyright (C) 2018 Universidad de Sevilla
 * 
 * The use of this project is hereby constrained to the conditions of the
 * TDG Licence, a copy of which you may download from
 * http://www.tdg-seville.info/License.html
 */

package controllers;

import java.text.SimpleDateFormat;
import java.util.Collection;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import services.SystemConfigService;

@Controller
@RequestMapping("/welcome")
public class WelcomeController extends AbstractController {

	//Call systemconfigservice, then get the url of the banner image, and add it as a attribute on the request.
	//then, on the view, on the image display, replace with the new attribute.

	// Constructors -----------------------------------------------------------

	@Autowired
	private SystemConfigService	scs;


	public WelcomeController() {
		super();
	}

	// Index ------------------------------------------------------------------		

	@RequestMapping(value = "/index")
	public ModelAndView index(@CookieValue("language") final String lang) {
		ModelAndView result;
		SimpleDateFormat formatter;
		String moment;

		final Collection<String> welcomeMessage = this.scs.getSystemConfig().getWelcomeMessage();

		formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm");
		moment = formatter.format(new Date());

		result = new ModelAndView("welcome/index");
		result.addObject("moment", moment);
		final String banner = this.scs.getSystemConfig().getBanner();
		result.addObject("bannerImage", banner);
		result.addObject("welcomeMessage", welcomeMessage);

		result.addObject("lang", lang);
		return result;
	}
}
