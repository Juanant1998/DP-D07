package converters;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;


import domain.FixUpTask;


@Component
@Transactional
public class FixUpTaskToStringConverter implements Converter<FixUpTask, String>{

	
		@Override
		public String convert(final FixUpTask f) {
			String result;
			
			if(f == null){
				result = null;
			}else{
				result = String.valueOf(f.getId());
			}
			
			return result;
		}
	

}
