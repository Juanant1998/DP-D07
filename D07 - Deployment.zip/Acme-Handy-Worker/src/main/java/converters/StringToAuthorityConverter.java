package converters;

import org.apache.commons.lang.StringUtils;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;



import security.Authority;



@Component
@Transactional
public class StringToAuthorityConverter implements Converter<String, Authority>{
	
	

	@Override
	public Authority convert(String text) {
		Authority result = null;
		
		try {
			if (StringUtils.isEmpty(text)){
				result = null;
			}else{
				if(text == "CUSTOMER"){
					Authority a = new Authority();
					a.setAuthority(Authority.CUSTOMER);
					result = a;
				}
				if(text == "HANDYWORKER"){
					Authority a = new Authority();
					a.setAuthority(Authority.HANDYWORKER);
					result = a;
				}
				if(text == "SPONSOR"){
					Authority a = new Authority();
					a.setAuthority(Authority.SPONSOR);
					result = a;
				}
				if(text == "ADMIN"){
					Authority a = new Authority();
					a.setAuthority(Authority.ADMIN);
					result = a;
				}
				if(text == "REFEREE"){
					Authority a = new Authority();
					a.setAuthority(Authority.REFEREE);
					result = a;
				}
			}
		} catch (Throwable oops){
			throw new IllegalArgumentException(oops);
			
		}
		
		return result;
		
	
	}
	
	

}
