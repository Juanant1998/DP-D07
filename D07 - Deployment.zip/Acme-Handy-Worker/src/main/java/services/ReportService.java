package services;

import java.util.Collection;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import repositories.ComplaintRepository;
import repositories.RefereeRepository;
import repositories.ReportRepository;
import security.Authority;
import security.LoginService;
import security.UserAccount;

import domain.Application;
import domain.Complaint;
import domain.FixUpTask;
import domain.Referee;
import domain.Report;


@Service
@Transactional
public class ReportService {
	
	@Autowired
	private ReportRepository reportRepository;
	@Autowired
	private ComplaintRepository complaintRepository;

	
	@Autowired
	private UserAccountService		uas;
	@Autowired
	private ComplaintService		complaintService;
	
	
	public void checkAuthority() {

		UserAccount user;
		user = LoginService.getPrincipal();
		Assert.notNull(user);
		final Collection<Authority> authority = user.getAuthorities();
		Assert.notNull(authority);
		final Authority a1 = new Authority();
		a1.setAuthority(Authority.REFEREE);
		Assert.isTrue(authority.contains(a1));

	}
	
	
	
	
	
	
	
	public Report create(){
		this.checkAuthority();
		
		Date d = new Date();
		Report r = new Report();
		r.setMoment(d);
		return  r;	
	}
	public Collection<Report> findAll(){
	this.checkAuthority();
		return reportRepository.findAll();
	}
	
	public Report findOne(int reportId){
		return reportRepository.findOne(reportId);
	}
	
	public Report save(Report report){
		this.checkAuthority();
	
	
		
		report.setReferee(this.uas.getRefereeByUserAccount(LoginService.getPrincipal()));
		return reportRepository.save(report);
	}
	
	public void delete(Report report){
		this.checkAuthority();
	List<Complaint> complaints = this.complaintRepository.findAll();
	for(Complaint c : complaints){
		if(c.getReport().equals(report)){
			c.setReport(null);
		}
	}
		
		Assert.isTrue(report.isDraftMode());
		reportRepository.delete(report);
	}
	
	public void relateComplaintToReport(final int complaintId, final Report savedreport) {
		final Complaint complaint = this.complaintService.findOne(complaintId);
	complaint.setReport(savedreport);
		this.complaintService.save(complaint);

	}
	

}