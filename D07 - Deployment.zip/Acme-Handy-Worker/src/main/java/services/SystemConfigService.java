package services;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import domain.SystemConfig;

import repositories.SystemConfigRepository;

@Transactional
@Service
public class SystemConfigService {
	
	@Autowired
	private SystemConfigRepository systemConfigRepository;
	
	public SystemConfig create(){
		return new SystemConfig();
	}
	
	public Collection<SystemConfig> findAll(){
		return systemConfigRepository.findAll();
	}
	
	public SystemConfig findOne(int systemConfigId){
		return systemConfigRepository.findOne(systemConfigId);
	}
	
	public SystemConfig save(SystemConfig systemConfig){
		return systemConfigRepository.save(systemConfig);
	}
	
	public void delete(SystemConfig systemConfig){
		systemConfigRepository.delete(systemConfig);
	}
	
	public SystemConfig getSystemConfig(){
		List<SystemConfig> x = new ArrayList<SystemConfig>();
		x.addAll(this.findAll());
		SystemConfig res;
		
		res = x.get(0);
		
		return res;
		
	}

}
