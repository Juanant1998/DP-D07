
package services;

import java.util.Collection;
import java.util.Collections;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import repositories.CategoryRepository;
import repositories.FinderRepository;
import repositories.FixUpTaskRepository;
import domain.Category;
import domain.Finder;
import domain.FixUpTask;

@Service
@Transactional
public class CategoryService {

	@Autowired
	private CategoryRepository	categoryRepository;
	@Autowired
	private FinderRepository	finderRepository;
	@Autowired
	private FixUpTaskRepository	fixRepository;
	


	public Category create() {
		return new Category();
	}
	public Collection<Category> findAll() {
		return this.categoryRepository.findAll();
	}
	public Category findOne(final int categoryId) {
		return this.categoryRepository.findOne(categoryId);
	}
	public Category save(final Category category) {
		return this.categoryRepository.save(category);
	}
	public void delete(final Category category) {
		
		Assert.isTrue(category.getId()!=0);
		final Collection<Category> categories = this.categoryRepository.findAll();
            List<FixUpTask> fixs = this.fixRepository.findAll();
		List<Finder> finds = this.finderRepository.findAll();
		for(FixUpTask f : fixs){
			if(f.getCategory().equals(category)){
				f.setCategory(this.categoryRepository.findOne(1552));
			}
		}
		
		
		
		for(Finder f :finds){
			if(f.getCategory().equals(category)){
				f.setCategory(null);
			}
		}
		
		
		for (final Category c : categories){
			
			Collection<Category> des = c.getDescendants();
			if (c.getDescendants().contains(category)){
			
			des.remove(category);
		c.setDescendants(des);
			}
	}
		this.categoryRepository.delete(category);

	}
}
