package services;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import repositories.ActorRepository;
import repositories.CustomerRepository;
import repositories.HandyWorkerRepository;
import repositories.MessageRepository;
import security.LoginService;
import security.UserAccount;
import security.UserAccountRepository;
import domain.Actor;
import domain.Administrator;
import domain.Application;
import domain.Customer;
import domain.HandyWorker;
import domain.Message;
import domain.MessageBox;


@Service
@Transactional
public class MessageService {
	
	@Autowired
	private MessageRepository messageRepository;
	
	@Autowired
	private ActorRepository ar;
	
	@Autowired
	private AdministratorService ads;
	
	@Autowired
	private UserAccountRepository ur;
	
	@Autowired
	private HandyWorkerRepository hr;
	
	public Message create(){
		Date date = new Date();
		Message m = new Message();
		final UserAccount actual = LoginService.getPrincipal();
		final Actor a = this.ar.getActor(actual);
		m.setMoment(date);
		m.setSender(a);
		System.out.println("create servicio:");
		System.out.println(m.getSender());
		return m;	
	}
	
	public Collection<Message> findAll(){
		return messageRepository.findAll();
	}
	
	public Message findOne(int messageId){
		return messageRepository.findOne(messageId);
	}
	
	public Message save(Message message){
		return messageRepository.save(message);
	}
	
	public void delete(Message message){
		messageRepository.delete(message);
	}

	public Message createAppMessage(Application a, Customer c){
		Date date = new Date();
		Message m = new Message();
		m.setMoment(date);
		
		List<Administrator> admins = (List<Administrator>) this.ads.findAll();
		
		m.setSender(admins.get(0));
		m.setBody("The status of an application related with you has changed, please check it out. \n Un estado de una aplicaci�n relacionada contigo ha cambiado, por favor rev�selo.");
		m.setSubject("Application status has been changed \n El estado de una aplicaci�n ha sido modificado");
		m.setPriority("HIGH");
		m.setTags("appChanged");
		
		HandyWorker h = this.hr.getHandyWorkerByApplication(a);
		
		List<Actor> recipients = new ArrayList<Actor>();
		recipients.add(c);
		recipients.add(h);
		m.setRecipients(recipients);
		
		Message saved = this.save(m);
		
		List<MessageBox> cboxes = (List<MessageBox>) c.getMessageBoxes();
		MessageBox inc = cboxes.get(0);
		Collection<Message> cMessages = inc.getMessages();
		cMessages.add(saved);
		inc.setMessages(cMessages);

		
		List<MessageBox> hboxes = (List<MessageBox>) h.getMessageBoxes();
		MessageBox inh = hboxes.get(0);
		Collection<Message> hMessages = inh.getMessages();
		hMessages.add(saved);
		inh.setMessages(hMessages);
		
		
		return m;	
	}
	
}
